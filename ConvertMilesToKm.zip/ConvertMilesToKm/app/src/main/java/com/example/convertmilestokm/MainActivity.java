package com.example.convertmilestokm;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button milesTokm = (Button) findViewById(R.id.button2);
        milesTokm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText textBoxmile = (EditText) findViewById(R.id.editText2 );
                EditText textBoxkm = (EditText) findViewById(R.id.editText3 );
                double vMiles = Double.valueOf(textBoxmile.getText().toString());
                double vKm = vMiles / 0.62137;
                DecimalFormat formatVal = new DecimalFormat("##.##");
                textBoxkm.setText(formatVal.format(vKm));
            }
        });
        Button kmTomiles = (Button) findViewById(R.id.button3);
        milesTokm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText textBoxmile = (EditText) findViewById(R.id.editText2 );
                EditText textBoxkm = (EditText) findViewById(R.id.editText3 );
                double vKm = Double.valueOf(textBoxkm.getText().toString());
                double vMiles  = vKm *  0.62137;
                DecimalFormat formatVal = new DecimalFormat("##.##");
                textBoxmile.setText(formatVal.format(vMiles));
            }
        });
    }
}
